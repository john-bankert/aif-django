from django.apps import AppConfig


class AifPlayerstomeConfig(AppConfig):
    name = 'aif_playerstome'
