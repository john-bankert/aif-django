from django.contrib.auth.models import User, Group, Permission
from django.core.management.base import BaseCommand, CommandError
from django.core.exceptions import ObjectDoesNotExist
from aif_character.models import Character
from aif_playerstome.models import Armor, Equipment, Weapons, Spells


class Command(BaseCommand):


    def add_arguments(self, parser):
        pass
        
    def handle(self, *args, **options):
        Armor.importData()
        Equipment.importData()
        Weapons.importData()
        Spells.importData()
        self.add_users()

        nc  = ['Chauncy', 'Human', 'Male', 'Warrior', 16, 14, 11, 16, True]
        self.add_demo_character(nc)
        
        nc  = ['Zandor', 'Elf', 'Male', 'Wizard', 10, 12, 18, 15, True]
        self.add_demo_character(nc)

        nc  = ['Fredo', 'Halfling', 'Male', 'Rogue', 12, 17, 10, 14, True]
        self.add_demo_character(nc)

        nc  = ['Brunie', 'Dwarf', 'Female', 'Priest', 12, 13, 16, 16, True]
        self.add_demo_character(nc)
        
        nc  = ['Elanor', 'Half Elf', 'Female', 'Bard', 14, 11, 16, 15, True]
        self.add_demo_character(nc)

        nc  = ['Zax', 'Gnome', 'Male', 'Illusionist', 14, 11, 16, 15, True]
        self.add_demo_character(nc)

        nc  = ['Prosser', 'Human', 'Male', 'Paladin', 17, 13, 12, 14, True]
        self.add_demo_character(nc)

        nc  = ['Boudica', 'Human', 'Female', 'Paladin/Priest', 17, 14, 16, 15, True]
        self.add_demo_character(nc)
        
        nc  = ['Rosie', 'Halfling', 'Female', 'Theurgist', 11, 14, 17, 15, True]
        self.add_demo_character(nc)

        #[BARBARIAN, BUCCANEER, CHARLATAN, DIVINER, DRUID, GYPSY, MAGICIAN, MONK, PARAGON, PROPHET, RANGER, SCOUT, THEURGIST, TEMPLAR, WARLOCK, WITCH]

        

    def add_users(self):
        self.add_user('John', 'jbankert@gmail.com', 'k72CD@&rsa49PKF', 'John', 'Bankert')
        self.add_user('demo', 'demo@aif.magichelmet.xyz', '1qaz2wsx!QAZ@WSX', 'Demo', 'User')
        self.add_user('Gamemaster', 'gamemaster@aif.magichelmet.xyz', '1234qwer!@#$QWER', 'Game', 'Masater')
        # new_group, created = Group.objects.get_or_create(name='game_master')
        # proj_add_perm = Permission.objects.get(name='Can add users to party')
        # new_group.permissions.add(proj_add_perm)
        # ct = ContentType.objects.get_for_model(Project)
        # permission = Permission.objects.create(codename='can_add_project', name='Can add project', content_type=ct)
        # new_group.permissions.add(permission)
        # new_group, created = Group.objects.get_or_create(name='aif_admin')

    def add_user(self, userName, email, password, firstName, lastName,):
        if User.objects.filter(username=userName).count() == 0:
            user = User.objects.create_user(userName, email, password)
            user.first_name = firstName
            user.last_name = lastName
            user.save()
            self.stdout.write("added user " + userName)
        else:
            self.stdout.write("user " + userName + " already exists")

    def add_demo_character(self, nc):
        if Character.objects.filter(name=nc[0]).count() == 0:
            self.stdout.write("Creating Character " + nc[0])
            c = Character()
            c.new(nc[0], nc[1], nc[2], nc[3], nc[4], nc[5], nc[6], nc[7])
            c.random_attributes()
        else:
            c = Character.objects.get(name=nc[0])
            self.stdout.write("Updating Character " + nc[0])
            
        c.player = 'demo'
        c.open = nc[8]
        c.save()

