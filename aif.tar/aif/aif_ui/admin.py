from django.contrib import admin

# Register your models here.
from aif_character.models import Character

admin.site.register(Character)