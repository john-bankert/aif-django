from django.apps import AppConfig


class AifUiConfig(AppConfig):
    name = 'aif_ui'
