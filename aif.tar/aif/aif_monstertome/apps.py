from django.apps import AppConfig


class AifMonstertomeConfig(AppConfig):
    name = 'aif_monstertome'
