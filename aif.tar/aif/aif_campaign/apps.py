from django.apps import AppConfig


class AifCampaignConfig(AppConfig):
    name = 'aif_campaign'
