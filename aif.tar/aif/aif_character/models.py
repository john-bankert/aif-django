import importlib
import os
import json
from django.core import serializers
import random
from django.db import models
from django.forms import ModelForm
from aif import constants as aif
from aif_campaign import functions as fn
from aif_playerstome import races, classes, spells

application_label = 'aif_character'


class Character(models.Model):
    name = models.CharField(max_length=100, default="")
    player = models.CharField(max_length=100, default="")
    party = models.CharField(max_length=100, default="")
    race = models.CharField(max_length=25, default="")
    char_class = models.CharField(max_length=50, default="")
    gender = models.CharField(max_length=25, default="")
    age = models.IntegerField(default=18)
    height = models.CharField(max_length=25, default="")
    weight = models.CharField(max_length=25, default="")
    notes = models.TextField()
    open = models.BooleanField(default=False)

    movement = models.CharField(max_length=10)
    walking_base = models.IntegerField(default=0)
    walking_buff = models.IntegerField(default=0)
    walking_adjusted = models.IntegerField(default=0)
    running_base = models.IntegerField(default=0)
    running_buff = models.IntegerField(default=0)
    running_adjusted = models.IntegerField(default=0)
    swimming_base = models.IntegerField(default=0)
    swimming_buff = models.IntegerField(default=0)
    swimming_adjusted = models.IntegerField(default=0)

    encumbrance = models.IntegerField(default=0)
    total_load = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)
    modifiers = models.IntegerField(default=0)
    burdened = models.IntegerField(default=0)

    level = models.IntegerField(default=1)
    experience = models.IntegerField(default=0)
    next_level = models.IntegerField(default=10)

    str_base = models.IntegerField(default=0)
    str_buff = models.IntegerField(default=0)
    str_adjusted = models.IntegerField(default=0)
    str_modifiers = models.CharField(max_length=10, default="")

    dex_base = models.IntegerField(default=0)
    dex_buff = models.IntegerField(default=0)
    dex_adjusted = models.IntegerField(default=0)
    dex_modifiers = models.CharField(max_length=10, default="")

    int_base = models.IntegerField(default=0)
    int_buff = models.IntegerField(default=0)
    int_adjusted = models.IntegerField(default=0)
    int_modifiers = models.CharField(max_length=10, default="")

    health_base = models.IntegerField(default=0)
    health_buff = models.IntegerField(default=0)
    health_adjusted = models.IntegerField(default=0)
    health_modifiers = models.CharField(max_length=10, default="")
    health_current = models.IntegerField(default=0)

    honor_points_base = models.IntegerField(default=0)
    honor_points_current = models.IntegerField(default=0)

    spell_points_base = models.IntegerField(default=0)
    spell_points_current = models.IntegerField(default=0)
    spell_effectiveness_modifier = models.IntegerField(default=0)
    rhythm_points_base = models.IntegerField(default=0)
    rhythm_points_current = models.IntegerField(default=0)
    spell_cards_base = models.IntegerField(default=0)
    spell_cards_current = models.IntegerField(default=0)

    knockdown_base = models.IntegerField(default=0)
    knockdown_buff = models.IntegerField(default=0)
    knockdown_cf_points = models.IntegerField(default=0)
    knockdown_adjusted = models.IntegerField(default=0)

    defense_base = models.IntegerField(default=0)
    defense_buff = models.IntegerField(default=0)
    defense_cf_points = models.IntegerField(default=0)
    defense_adjusted = models.IntegerField(default=0)

    stun_base = models.IntegerField(default=0)
    stun_buff = models.IntegerField(default=0)
    stun_cf_points = models.IntegerField(default=0)
    stun_adjusted = models.IntegerField(default=0)
    stun_current = models.IntegerField(default=0)

    endurance_base = models.IntegerField(default=0)
    endurance_cf_points = models.IntegerField(default=0)
    endurance_buff = models.IntegerField(default=0)
    endurance_adjusted = models.IntegerField(default=0)

    fatigue = models.IntegerField(default=0)
    extra_fatigue = models.IntegerField(default=0)

    withstand_dice = models.IntegerField(default=3)
    withstand_modifiers = models.CharField(max_length=10)
    withstand_adjusted = models.CharField(max_length=10)

    dodge_dice = models.IntegerField(default=3)
    dodge_modifiers = models.CharField(max_length=10)
    dodge_adjusted = models.CharField(max_length=10)

    resist_dice = models.IntegerField(default=3)
    resist_modifiers = models.CharField(max_length=10)
    resist_adjusted = models.CharField(max_length=10)

    damage_dice_base = models.IntegerField(default=0)
    damage_dice_buff = models.IntegerField(default=0)
    damage_dice_adjusted = models.CharField(max_length=15)

    damage_mods_base = models.IntegerField(default=0)
    damage_mods_buff = models.IntegerField(default=0)
    damage_mods_adjusted = models.CharField(max_length=15)

    damage_adjusted = models.CharField(max_length=15)

    to_hit_dice_base = models.IntegerField(default=0)
    to_hit_dice_buff = models.IntegerField(default=0)
    to_hit_dice_adjusted = models.CharField(max_length=15)

    to_hit_mods_base = models.IntegerField(default=0)
    to_hit_mods_buff = models.IntegerField(default=0)
    to_hit_mods_adjusted = models.CharField(max_length=15)

    to_hit_adjusted = models.CharField(max_length=15)

    actions_base = models.IntegerField(default=1)
    actions_buff = models.IntegerField(default=0)
    actions_adjusted = models.CharField(max_length=15)

    outside_search_dice = models.IntegerField(default=3)
    outside_search_modifiers = models.IntegerField(default=0)
    outside_search_adjusted = models.CharField(max_length=15)

    underground_search_dice = models.IntegerField(default=3)
    underground_search_modifiers = models.IntegerField(default=0)
    underground_search_adjusted = models.CharField(max_length=15)

    spbc_buff = models.IntegerField(default=0)

    gold_amount = models.IntegerField(default=0)
    gold_load = models.DecimalField(max_digits=5, decimal_places=1, default=0.0)

    silver_amount = models.IntegerField(default=0)
    silver_load = models.DecimalField(max_digits=5, decimal_places=1, default=0.0)

    copper_amount = models.IntegerField(default=0)
    copper_load = models.DecimalField(max_digits=5, decimal_places=1, default=0.0)

    current_round = models.IntegerField(default=0)
    mastered_count = models.IntegerField(default=0)
    game_day = models.IntegerField(default=0)
    game_time = models.CharField(max_length=5)

    class Meta:
        app_label = application_label

    def __str__(self):
        return self.name
        
    def new(self, character_name="", character_race="", character_gender="", character_class="", _str=0, _dex=0, _int=0, _hlth=0):

        self.name = character_name

        self.race = character_race
        if character_race != "":
            _race = getattr(importlib.import_module("aif_playerstome.races"), self.race.replace(" ", ""))()
            self.walking_base = _race.movement
            self.running_base = _race.movement * 2
            self.swimming_base = round(_race.movement / 2)
            self.withstand_dice = _race.save_dice[aif.WITHSTAND]
            self.withstand_modifiers = _race.save_bonuses[aif.WITHSTAND]
            self.dodge_dice = _race.save_dice[aif.DODGE]
            self.dodge_modifiers = _race.save_bonuses[aif.DODGE]
            self.resist_dice = _race.save_dice[aif.RESIST]
            self.resist_modifiers = _race.save_bonuses[aif.RESIST]
            self.outside_search_dice = _race.search_dice[aif.OUTSIDE]
            self.outside_search_modifiers = _race.search_bonuses[aif.OUTSIDE]
            self.underground_search_dice = _race.search_dice[aif.UNDERGROUND]
            self.underground_search_modifiers = _race.search_bonuses[aif.UNDERGROUND]
            self.save()

            for skill in _race.racial_skills:
                rs = self.racialskills_set.create(item_name=skill)
                rs.save()

        self.char_class = character_class
        self.save()
        _classes = {}
        if character_class != "":
            for cls in self.char_class.split("/"):
                _classes[cls] = getattr(importlib.import_module("aif_playerstome.classes"), cls)()
 
            class_skills = []
            for cls in _classes:
                class_skills.extend(_classes[cls].skills_list)
            class_skills = sorted(class_skills)

            for skill in class_skills:
                cs = self.classskills_set.create(item_name=skill)
                cs.save()

            if aif.PALADIN in self.char_class:
                self.honor_points_base = 2
                self.honor_points_current = self.honor_points_base
                _classes[aif.PALADIN].honor_skills_list
                for skill in _classes[aif.PALADIN].honor_skills_list:
                    hs = self.honorskills_set.create(item_name=skill)
                    hs.save()

            if aif.ILLUSIONIST in self.char_class:
                _classes[aif.ILLUSIONIST].spell_skills_list
                for skill in _classes[aif.ILLUSIONIST].spell_skills_list:
                    ss = self.spellskills_set.create(item_name=skill)
                    ss.save()
                    
            #if aif.BARD in self.char_class:
            #    spell_list = _spells.get_spells_list(aif.BARD)

        self.gender = character_gender
        self.str_base = _str
        self.dex_base = _dex
        self.int_base = _int
        self.health_base = _hlth

        self.encumbrance = self.str_base * 2
        self.burdened = self.str_base

        self.knockdown_base = round(self.str_base / 2)
        self.defense_base = round((self.str_base + self.dex_base + self.int_base) / 3)
        self.stun_base = round(self.int_base / 2)
        self.endurance_base = self.health_base

        self.damage_dice_base = 0
        self.to_hit_dice_base = 3
        self.actions_base = 1

        weapons_types = {aif.SLASHING_GRP: "S", aif.PIERCING_GRP: "P", aif.BLUDGEONING_GRP: "B", 
                            aif.CLEAVING_GRP: "C", aif.THROWING_GRP: "-", aif.BOW_GRP: "-"}
        for weapon in weapons_types:
            w = self.weapons_set.create(item_name=weapon)
            w.size = "-"
            w.type = weapons_types[weapon]
            w.load = "-"
            w.save()

        armor_types = {aif.LIGHT_GRP: "L", aif.MEDIUM_GRP: "M", aif.HEAVY_GRP: "H", aif.HELMET_GRP: "-",
                        aif.UNARMED_GRP: "U", aif.SHIELD_GRP: "S"}
        for armor in armor_types:
            a = self.armor_set.create(item_name=armor)
            a.type = armor_types[armor]
            a.load = "-"
            
        self.save()

    def random(self):

        _name = ""
        for idx in range(1, random.randint(7, 12)):
            ascii_char = chr(random.randint(97, 122))
            _name += ascii_char.upper() if idx == 1 else ascii_char

        _race = races.race_list[random.randint(0, len(races.race_list) - 1)]
        _class = classes.class_list[random.randint(0, len(classes.class_list) - 1)]

        cl_race = getattr(importlib.import_module("aif_playerstome.races"), _race.replace(" ", ""))()
        rd6 = cl_race.racial_d6[random.randint(0, len(cl_race.racial_d6) - 1)]
        dice = {aif.STR: 3, aif.INT: 3, aif.DEX: 3, aif.HLTH: 3}
        dice[rd6] += 1
        _str = fn.roll_dice(dice[aif.STR])
        _dex = fn.roll_dice(dice[aif.DEX])
        _int = fn.roll_dice(dice[aif.INT])
        _health = fn.roll_dice(dice[aif.HLTH])
        _gender = "Male" if random.randint(0, 1) == 0 else "Female"

        self.new(_name, _race, _gender, _class, _str, _dex, _int, _health)
        self.random_attributes()
        self.save()

    def random_attributes(self):
        _race = getattr(importlib.import_module("aif_playerstome.races"), self.race.replace(" ", ""))()
        hw = _race.attributes[self.gender].split(",")
        self.age = self.variance(_race.attributes[aif.AGE])
        self.height = self.format_height(self.variance(int(hw[0])))
        self.weight = self.variance(int(hw[1]))

        self.silver_amount = random.randint(1, 20)
        self.copper_amount = random.randint(1, 20)
        self.save()
        
    def is_spellcaster(self):
        is_sc = self.char_class in aif.spell_casters
        if "/" in self.char_class:
            for _cn in self.char_class.split("/"):
                if _cn in aif.spell_casters:
                    is_sc = True
                    break
        return is_sc

    def adjust(self):

        self.total_load = 0

        self.gold_load = self.gold_amount / 100
        self.silver_load = self.silver_amount / 100
        self.copper_load = self.copper_amount / 100

        self.total_load += self.gold_load + self.silver_load + self.copper_load
        self.save()

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/character.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Character.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")

    @staticmethod
    def dice_mod_string(_number):
        number = str(_number)
        return "" if number == "0" else (("" if number[:1] == "-" else "+") + number)

    @staticmethod
    def variance(number_in):
        ten_pct = round(number_in / 10)
        var = random.randint((-1 * ten_pct), ten_pct)
        return number_in + var

    @staticmethod
    def format_height(number_in):
        feet = int(number_in / 12)
        inches = number_in - (feet * 12)
        return str(feet) + "' " + str(inches) + "\""

    @staticmethod
    def ability_score_mod(ability):
        if ability < 4:
            return -3
        elif ability < 6:
            return -2
        elif ability < 8:
            return -1
        elif ability < 14:
            return 0
        else:
            i = 1
            while ability > (13 + (i * 2)):
                i += 1
            return i

    @staticmethod
    def generate_xp_dict():
        xp = 0
        xp_dict = {}
        xp_list = []
        for level in range(31):
            steps = 5 + level
            multiple = 2 * (level + 1)
            for step in range(steps):
                xp += multiple
                xp_list.append(xp)
                
            _last = xp_list[-1]
            del xp_list[-1]
            xp_list.append(_last - 1)
            xp_dict[level + 1] = xp_list
            xp_list = [_last]
            # if _debug:
            #    print(str(level + 1) + ": " + str(xp_dict[level + 1][0]) + " - " + str(xp_dict[level + 1][-1]) +
            #          " : " + str(steps) + " steps,  multiple = " + str(multiple))
        return xp_dict

    @staticmethod
    def order(rank):
        return int(rank / 4)


class ClassSkills(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200, default="")
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    buff = models.IntegerField(default=0)
    adjusted = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/class_skills.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(ClassSkills.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class RacialSkills(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200, default="")
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    buff = models.IntegerField(default=0)
    adjusted = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/racial_skills.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(RacialSkills.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class HonorSkills(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200, default="")
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    buff = models.IntegerField(default=0)
    adjusted = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/honor_skills.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(HonorSkills.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class SpellSkills(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200, default="")
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    buff = models.IntegerField(default=0)
    adjusted = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/spell_skills.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(SpellSkills.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class Spells(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    name = models.CharField(max_length=75, default="")
    circle = models.IntegerField(default=0)
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    adjusted = models.IntegerField(default=0)
    buff = models.IntegerField(default=0)
    vessel = models.BooleanField(default=False)
    vessel_power = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label
        
    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/spells.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Spells.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")

        
class Weapons(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200, default="")
    size = models.CharField(max_length=5, default="")
    type = models.CharField(max_length=5, default="")
    damage = models.CharField(max_length=5, default="")
    range = models.CharField(max_length=5, default="")
    durability = models.CharField(max_length=5, default="")
    load = models.CharField(max_length=5, default="")
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/weapons.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Weapons.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class Armor(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200, default="")
    type = models.CharField(max_length=5, default="")
    durability = models.CharField(max_length=5, default="")
    slashing = models.CharField(max_length=5, default="")
    piercing = models.CharField(max_length=5, default="")
    bludgeoning = models.CharField(max_length=5, default="")
    cleaving = models.CharField(max_length=5, default="")
    load = models.CharField(max_length=5, default="")
    carried = models.CharField(max_length=5, default="")
    rank = models.IntegerField(default=0)
    order = models.IntegerField(default=0)
    mastered = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/armor.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Armor.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class Container(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    item_name = models.CharField(max_length=75, default="")
    description = models.CharField(max_length=200)
    max_load_capacity = models.DecimalField(max_digits=5, decimal_places=1)
    current_load = models.DecimalField(max_digits=5, decimal_places=1)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/container.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Container.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class Equipment(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    container = models.ForeignKey(Container, on_delete=models.CASCADE)
    description = models.CharField(max_length=200)
    durability = models.CharField(max_length=5)
    adjusted = models.CharField(max_length=5)
    load = models.DecimalField(max_digits=5, decimal_places=1)
    quantity = models.IntegerField()
    worn = models.BooleanField(default=False)
    in_container = models.BooleanField(default=False)

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/equipment.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Equipment.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class Tips(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    tip = models.TextField()

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/tips.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Tips.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class Buffs(models.Model):
    character = models.ForeignKey(Character, on_delete=models.CASCADE)
    buff = models.TextField()

    # {aif.METHOD: method, aif.START: start, aif.DURATION: duration, aif.BASE + aif.DURATION: duration,
    #        aif.EFFECTS: effects, aif.DESC: desc[:-2], aif.RANK: rank,
    #        aif.DATE: char[aif.DATE], aif.TIME: char[aif.TIME]}

    class Meta:
        app_label = application_label

    @staticmethod
    def serialize():
        try:
            fn = os.path.dirname(os.path.realpath(__file__)) + "/data/buffs.json"
            JSONSerializer = serializers.get_serializer("json")
            json_serializer = JSONSerializer()
            json_serializer.serialize(Buffs.objects.all())
            with open(fn, "w") as out:
                out.write(json.dumps(json.loads(json_serializer.getvalue()), indent=4))
        except FileNotFoundError:
            print("file not found")


class CharacterForm(ModelForm):
    class Meta:
        model = Character
        fields = ['name', 'race', 'gender', 'age', 'weight', 'height', 'experience',
                  'str_base', 'dex_base', 'int_base', 'health_base', 'knockdown_adjusted',
                  'defense_adjusted', 'stun_adjusted', 'endurance_adjusted']


class ClassSkillsForm(ModelForm):
    class Meta:
        model = ClassSkills
        fields = ['item_name', 'rank', 'mastered']



'''    

        # Fatigue Penalty
        fatigue_penalty = 0
        if "Yawp" not in self[aif.BUFFS_LIST]:
            if self[aif.FATIGUE] and self[aif.FATIGUE] > 0:
                fatigue_penalty = -2 * int(self[aif.FATIGUE] / self[aif.ENDURANCE][aif.ADJ])

        for field in [aif.MOVEMENT, aif.WALKING, aif.STR, aif.DEX, aif.INT, aif.HLTH, aif.KNOCKDOWN, aif.DEFENSE,
                      aif.STUN, aif.ENDURANCE, aif.DAMAGE + aif.DICE, aif.DAMAGE + aif.MODIFIERS,
                      aif.TO_HIT + aif.DICE, aif.TO_HIT + aif.MODIFIERS, aif.ACTIONS, aif.SPBC_BUFF]:
            if isinstance(self[field], dict):
                self[field][aif.BUFF] = 0
            else:
                self[field] = 0

        for buff in self[aif.BUFFS_LIST]:
            if "classes.Paladin.recover_" in self[aif.BSP + buff][aif.METHOD]:
                continue
            else:
                pass
            effects = self[aif.BSP + buff][aif.EFFECTS]
            for effect in effects:
                fields = effect[aif.FIELD].split("::")
                if isinstance(effect[aif.BUFF], str):
                    if "::" not in effect[aif.FIELD]:
                        self[fields[0]] = effect[aif.BUFF]
                    else:
                        self[fields[0]][fields[1]] = effect[aif.BUFF]
                else:
                    if "::" not in effect[aif.FIELD]:
                        self[fields[0]] += effect[aif.BUFF]
                    else:
                        self[fields[0]][fields[1]] += effect[aif.BUFF]

        # Buff stats, get new buffed stat bonuses
        move_mods = 0
        for stat in [aif.STR, aif.DEX, aif.INT]:
            self[stat][aif.ADJ] = self[stat][aif.BASE] + self[stat][aif.BUFF]
            asm = Fn.ability_score_mod(self[stat][aif.ADJ])
            move_mods += asm
            self[stat][aif.MODIFIERS] = ("+" if asm > 0 else "") + str(asm)
        self[aif.HLTH][aif.ADJ] = self[aif.HLTH][aif.BASE] + self[aif.HLTH][aif.BUFF]
        self[aif.HLTH][aif.MODIFIERS] = "-"

        # adjust movement based on buffed stats
        self[aif.WALKING][aif.ADJ] = self[aif.WALKING][aif.BASE] + self[aif.WALKING][aif.BUFF] + move_mods + \
            fatigue_penalty
        # check for movement buff - right now only from speed, 
        if self[aif.MOVEMENT][aif.BUFF]:
            if isinstance(self[aif.MOVEMENT][aif.BUFF], str) and "*" in self[aif.MOVEMENT][aif.BUFF]:
                self[aif.WALKING][aif.ADJ] = self[aif.WALKING][aif.ADJ] * int(self[aif.MOVEMENT][aif.BUFF][1:])
        # running & swimming from walking
        self[aif.RUNNING][aif.ADJ] = self[aif.WALKING][aif.ADJ] * 2
        self[aif.SWIMMING][aif.ADJ] = round(self[aif.WALKING][aif.ADJ] / 2)

        xp_dict = Fn.generate_xp_dict()
        for level in xp_dict:
            low = xp_dict[level][0]
            high = xp_dict[level][-1]
            if level == 1:
                low = 0
            if low <= self[aif.EXPERIENCE] <= high:
                self[aif.LEVEL] = level
                self[aif.NEXT_LEVEL] = high + 1
                break

        # update save roll stat bonuses
        self[aif.WITHSTAND][aif.MODIFIERS] = int(self[aif.STR][aif.MODIFIERS]) + fatigue_penalty
        self[aif.WITHSTAND][aif.MODIFIERS] = ("+" if self[aif.WITHSTAND][aif.MODIFIERS] > 0 else "") + \
            str(self[aif.WITHSTAND][aif.MODIFIERS])
        self[aif.DODGE][aif.MODIFIERS] = int(self[aif.DEX][aif.MODIFIERS]) + fatigue_penalty
        self[aif.DODGE][aif.MODIFIERS] = ("+" if self[aif.DODGE][aif.MODIFIERS] > 0 else "") + \
            str(self[aif.DODGE][aif.MODIFIERS])
        self[aif.RESIST][aif.MODIFIERS] = int(self[aif.INT][aif.MODIFIERS]) + fatigue_penalty
        self[aif.RESIST][aif.MODIFIERS] = ("+" if self[aif.RESIST][aif.MODIFIERS] > 0 else "") + \
            str(self[aif.RESIST][aif.MODIFIERS])

        self[aif.WITHSTAND][aif.ADJ] = str(self[aif.WITHSTAND][aif.DICE]) + "d6" + \
            (self[aif.WITHSTAND][aif.MODIFIERS] if not self[aif.WITHSTAND][aif.MODIFIERS] == "0" else "")
        self[aif.DODGE][aif.ADJ] = str(self[aif.DODGE][aif.DICE]) + "d6" + \
            (self[aif.DODGE][aif.MODIFIERS] if not self[aif.DODGE][aif.MODIFIERS] == "0" else "")
        self[aif.RESIST][aif.ADJ] = str(self[aif.RESIST][aif.DICE]) + "d6" + \
            (self[aif.RESIST][aif.MODIFIERS] if not self[aif.RESIST][aif.MODIFIERS] == "0" else "")

        # update combat factor base value on buffed stats
        self[aif.KNOCKDOWN][aif.BASE] = round(self[aif.STR][aif.ADJ] / 2)
        self[aif.STUN][aif.BASE] = round(self[aif.INT][aif.ADJ] / 2)
        self[aif.DEFENSE][aif.BASE] = round((self[aif.STR][aif.ADJ] + self[aif.DEX][aif.ADJ] +
                                             self[aif.INT][aif.ADJ]) / 3)

        # add in combat factor adjustments from leveling
        self[aif.KNOCKDOWN][aif.ADJ] = self[aif.KNOCKDOWN][aif.BASE] + self[aif.KNOCKDOWN][aif.CF_ADJ] + \
            self[aif.KNOCKDOWN][aif.BUFF]
        self[aif.STUN][aif.ADJ] = self[aif.STUN][aif.BASE] + self[aif.STUN][aif.CF_ADJ] + \
            self[aif.STUN][aif.BUFF]
        self[aif.DEFENSE][aif.ADJ] = self[aif.DEFENSE][aif.BASE] + self[aif.DEFENSE][aif.CF_ADJ] + \
            self[aif.DEFENSE][aif.BUFF] + fatigue_penalty
        self[aif.ENDURANCE][aif.ADJ] = self[aif.ENDURANCE][aif.BASE] + self[aif.ENDURANCE][aif.CF_ADJ] + \
            self[aif.ENDURANCE][aif.BUFF]

        # update to hit/damage modifier display values
        # This should include dice bonuses from things like onslaught spell. Needs to be fixed.
        self[aif.TO_HIT + aif.MODIFIERS][aif.BASE] = int(self[aif.DEX][aif.MODIFIERS])
        self[aif.DAMAGE + aif.MODIFIERS][aif.BASE] = int(self[aif.STR][aif.MODIFIERS])
        self[aif.TO_HIT + aif.MODIFIERS][aif.BUFF] += fatigue_penalty
        # check on this
        # self[aif.DAMAGE + aif.MODIFIERS][aif.BUFF] += fatigue_penalty

        # include action modifiers from things like speed spell
        self[aif.ACTIONS][aif.ADJ] = str(self[aif.ACTIONS][aif.BASE] + self[aif.ACTIONS][aif.BUFF])

        # set search roll display strings
        self[aif.OUTSIDE][aif.ADJ] = str(self[aif.OUTSIDE][aif.DICE]) + "d6" + \
            Fn.dice_mod_string(self[aif.OUTSIDE][aif.MODIFIERS] + fatigue_penalty)
        self[aif.UNDERGROUND][aif.ADJ] = str(self[aif.UNDERGROUND][aif.DICE]) + "d6" + \
            Fn.dice_mod_string(self[aif.UNDERGROUND][aif.MODIFIERS] + fatigue_penalty)

        # get racial skill descriptions. Refactor so it's not constantly being called.
        descriptions = self.race.get_racial_skill_descriptions(self[aif.RACIAL_SKILLS])
        for skill in descriptions:
            self[aif.RSP + skill][aif.DESC] = descriptions[skill]

        # initialize var to track number of mastered skills
        mastered_skills = 0

        # calculate racial skill order values from rank
        for skill in self[aif.RACIAL_SKILLS]:
            self[aif.RSP + skill][aif.ADJ] = self[aif.RSP + skill][aif.MODIFIERS] + self[aif.RSP + skill][aif.RANK]
            self[aif.RSP + skill][aif.ORDER] = int(self[aif.RSP + skill][aif.ADJ] / 4)
            if skill == "Toughness":
                if aif.ASP + skill not in self:
                    self[aif.ASP + skill] = {aif.TYPE: "", aif.DURABILITY: "", aif.SLASHING: "", aif.PIERCING: "",
                                             aif.BLUDGEONING: "", aif.CLEAVING: "", aif.LOAD: "-", aif.RANK: 0}
                self[aif.ASP + skill][aif.RANK] = self[aif.RSP + skill][aif.ADJ]

            if self[aif.RSP + skill][aif.MASTERED]:
                mastered_skills += 1

        # calculate class skill order values from rank
        for skill in self[aif.CLASS_SKILLS]:
            self[aif.CSP + skill][aif.ADJ] = self[aif.CSP + skill][aif.MODIFIERS] + self[aif.CSP + skill][aif.RANK]
            self[aif.CSP + skill][aif.ORDER] = int(self[aif.CSP + skill][aif.ADJ] / 4)
            if self[aif.CSP + skill][aif.MASTERED]:
                mastered_skills += 1

        # calculate honor skill order values from rank
        for skill in self[aif.HONOR_SKILLS]:
            self[aif.HSP + skill][aif.ADJ] = self[aif.HSP + skill][aif.MODIFIERS] + self[aif.HSP + skill][aif.RANK]
            self[aif.HSP + skill][aif.ORDER] = int(self[aif.HSP + skill][aif.ADJ] / 4)
            if self[aif.HSP + skill][aif.MASTERED]:
                mastered_skills += 1

        # calculate spell order values from rank

        # apply racial skill buffs/get racial skill tips
        self.race.apply_skills(self)

        # apply class skill buffs/get class skill tips
        for cls in self.classes:
            self.classes[cls].apply_skills(self)

        # calculate weapon order values, get SPBC order values to buff damage dice, calculate total weapon load
        spbc = {}
        self[aif.WSP + aif.TOTAL_LOAD] = 0
        for weapon in self[aif.WEAPONS_LIST]:
            self[aif.WSP + weapon][aif.ORDER] = int(self[aif.WSP + weapon][aif.RANK] / 4)
            if aif.GROUP in weapon:
                spbc[self[aif.WSP + weapon][aif.TYPE]] = self[aif.WSP + weapon][aif.ORDER]
            if not isinstance(self[aif.WSP + weapon][aif.LOAD], str) and self[aif.WSP + weapon][aif.LOAD] > 0:
                self[aif.WSP + aif.TOTAL_LOAD] += self[aif.WSP + weapon][aif.LOAD]
            if self[aif.WSP + weapon][aif.MASTERED]:
                mastered_skills += 1

        # calculate weapon to hit/damage dice rolls with buffs applied.
        for weapon in self[aif.WEAPONS_LIST]:
            self[aif.WSP + weapon][aif.TO_HIT] = ""
            self[aif.WSP + weapon][aif.DAMAGE + aif.ADJ] = ""

            # filter out weapons groups
            if aif.GROUP in weapon or self[aif.WSP + weapon][aif.SIZE] == "-":
                continue

            self[aif.WSP + weapon][aif.MELEE + aif.ADJ] = ""
            self[aif.WSP + weapon][aif.MISSILE + aif.ADJ] = ""

            # factor in modifiers for melee and missile to hit
            thmodstr = ""
            if aif.MELEE in self[aif.WSP + weapon] and self[aif.WSP + weapon][aif.MELEE]:
                if aif.MELEE + aif.MODIFIERS in self[aif.WSP + weapon]:
                    ms = self[aif.WSP + weapon][aif.MELEE + aif.MODIFIERS] + \
                         self[aif.TO_HIT + aif.MODIFIERS][aif.BASE] + self[aif.TO_HIT + aif.MODIFIERS][aif.BUFF]
                    self[aif.WSP + weapon][aif.MELEE + aif.ADJ] = Fn.dice_mod_string(ms)
                    thmodstr = self[aif.WSP + weapon][aif.MELEE + aif.ADJ]
            if aif.MISSILE in self[aif.WSP + weapon] and self[aif.WSP + weapon][aif.MISSILE]:
                if aif.MISSILE + aif.MODIFIERS in self[aif.WSP + weapon]:
                    ms = self[aif.WSP + weapon][aif.MISSILE + aif.MODIFIERS] + \
                         self[aif.TO_HIT + aif.MODIFIERS][aif.BASE] + self[aif.TO_HIT + aif.MODIFIERS][aif.BUFF]
                    self[aif.WSP + weapon][aif.MISSILE + aif.ADJ] = Fn.dice_mod_string(ms)
                    thmodstr += "" if thmodstr == "" else "/"
                    thmodstr += self[aif.WSP + weapon][aif.MISSILE + aif.ADJ]

            # calculate to hit dice - base + any buffs.
            nd = self[aif.TO_HIT + aif.DICE][aif.BASE] + self[aif.TO_HIT + aif.DICE][aif.BUFF]

            self[aif.WSP + weapon][aif.TO_HIT] = str(nd + self[aif.WSP + weapon][aif.ORDER]) + "d6" + thmodstr
            dmg = self[aif.WSP + weapon][aif.DAMAGE].split("d6")
            dmg[0] = int(dmg[0]) + spbc[self[aif.WSP + weapon][aif.TYPE]] + self[aif.DAMAGE + aif.DICE][aif.BUFF]
            if len(dmg) == 1:
                dmg.append(0)
            if dmg[1] == '':
                dmg[1] = 0
            dmg[1] = int(dmg[1]) + int(
                self[aif.STR][aif.MODIFIERS] if not self[aif.STR][aif.MODIFIERS] == "" else "0")
            self[aif.WSP + weapon][aif.DAMAGE + aif.ADJ] = str(dmg[0]) + "d6" + Fn.dice_mod_string(dmg[1])
            if aif.MELEE in self[aif.WSP + weapon] and self[aif.WSP + weapon][aif.MELEE]:
                d6 = str(nd + self[aif.WSP + weapon][aif.ORDER] + dmg[0]) + "d6"
                ms = dmg[1] + (0 if self[aif.WSP + weapon][aif.MELEE + aif.ADJ] == ""
                               else int(self[aif.WSP + weapon][aif.MELEE + aif.ADJ]))
                self[aif.WSP + weapon][aif.MELEE + aif.ADJ] = d6 + Fn.dice_mod_string(ms)
            if aif.MISSILE in self[aif.WSP + weapon] and self[aif.WSP + weapon][aif.MISSILE]:
                d6 = str(nd + self[aif.WSP + weapon][aif.ORDER] + dmg[0]) + "d6"
                ms = dmg[1] + (0 if self[aif.WSP + weapon][aif.MISSILE + aif.ADJ] == ""
                               else int(self[aif.WSP + weapon][aif.MISSILE + aif.ADJ]))
                self[aif.WSP + weapon][aif.MISSILE + aif.ADJ] = d6 + Fn.dice_mod_string(ms)

        # calculate armor order values, total armor load
        self[aif.ASP + aif.TOTAL_LOAD] = 0
        defense_adj = 0
        for spbc in [aif.SLASHING, aif.PIERCING, aif.BLUDGEONING, aif.CLEAVING]:
            self[aif.ASP + aif.TOTAL + spbc] = str(self[aif.SPBC_BUFF]) + "/" + str(self[aif.SPBC_BUFF])

        for armor in self[aif.ARMOR_LIST]:
            self[aif.ASP + armor][aif.ORDER] = ""
            ordered = False
            if isinstance(self[aif.ASP + armor][aif.RANK], int):
                self[aif.ASP + armor][aif.ORDER] = int(self[aif.ASP + armor][aif.RANK] / 4)
                ordered = True
                if aif.GROUP in armor:
                    defense_adj += self[aif.ASP + armor][aif.ORDER]

            for spbc in [aif.SLASHING, aif.PIERCING, aif.BLUDGEONING, aif.CLEAVING]:
                self[aif.ASP + armor][spbc + aif.ADJ] = self[aif.ASP + armor][spbc]
                if aif.GROUP not in armor and not self[aif.ASP + armor][aif.LOAD] == "-":
                    if ordered:
                        self[aif.ASP + armor][spbc + aif.ADJ] += self[aif.ASP + armor][aif.ORDER]
                    t_spbc = self[aif.ASP + aif.TOTAL + spbc].split("/")
                    if "helm" in armor.lower():
                        t_spbc[1] = int(t_spbc[1]) + int(self[aif.ASP + armor][spbc + aif.ADJ])
                    else:
                        t_spbc[0] = int(t_spbc[0]) + int(self[aif.ASP + armor][spbc + aif.ADJ])
                        t_spbc[1] = int(t_spbc[1]) + int(self[aif.ASP + armor][spbc + aif.ADJ])
                    self[aif.ASP + aif.TOTAL + spbc] = str(t_spbc[0]) + "/" + str(t_spbc[1])
            if not isinstance(self[aif.ASP + armor][aif.LOAD], str):
                if self[aif.ASP + armor][aif.LOAD] > 0:
                    self[aif.ASP + aif.TOTAL_LOAD] += self[aif.ASP + armor][aif.LOAD]
            if self[aif.ASP + armor][aif.MASTERED]:
                mastered_skills += 1

        for spbc in [aif.SLASHING, aif.PIERCING, aif.BLUDGEONING, aif.CLEAVING]:
            t_spbc = self[aif.ASP + aif.TOTAL + spbc].split("/")
            if int(t_spbc[0]) == int(t_spbc[1]):
                self[aif.ASP + aif.TOTAL + spbc] = t_spbc[0]

        self[aif.DEFENSE][aif.ADJ] += defense_adj

        self[aif.MASTERED] = mastered_skills

        nd = self[aif.TO_HIT + aif.DICE][aif.BUFF]
        dice_str = str(nd) + "d6" if nd > 0 else ""
        self[aif.TO_HIT + aif.ADJ] = dice_str + \
            Fn.dice_mod_string(self[aif.TO_HIT + aif.MODIFIERS][aif.BASE] + self[aif.TO_HIT + aif.MODIFIERS][aif.BUFF])

        nd = self[aif.DAMAGE + aif.DICE][aif.BUFF]
        dice_str = str(nd) + "d6" if nd > 0 else ""
        self[aif.DAMAGE + aif.ADJ] = dice_str + \
            Fn.dice_mod_string(self[aif.DAMAGE + aif.MODIFIERS][aif.BASE] + self[aif.DAMAGE + aif.MODIFIERS][aif.BUFF])

        _containers = {aif.CONTAINER_1: aif.C1P, aif.CONTAINER_2: aif.C2P, aif.CONTAINER_3: aif.C3P,
                       aif.CONTAINER_4: aif.C4P}
        for container in self[aif.CONTAINER_LIST]:
            if any(key.startswith(_containers[container]) for key in self):
                _total_load = 0
                for k2 in self:
                    if k2.startswith(_containers[container]):
                        if isinstance(self[k2], dict):
                            if aif.WORN in self[k2] and self[k2][aif.WORN]:
                                pass
                            elif aif.IN_CONTAINER in self[k2] and self[k2][aif.IN_CONTAINER]:
                                pass
                            else:
                                _total_load += self[k2][aif.LOAD]
                self[_containers[container] + aif.TOTAL_LOAD] = _total_load

        self[aif.ENCUMBRANCE] = (self[aif.STR][aif.ADJ] * 2) + self[aif.MODIFIERS]
        self[aif.BURDENED] = self[aif.STR][aif.ADJ] + self[aif.MODIFIERS]
        self[aif.TOTAL_LOAD] = self[aif.WSP + aif.TOTAL_LOAD] + self[aif.ASP + aif.TOTAL_LOAD]
        for container in self[aif.CONTAINER_LIST]:
            if (_containers[container] + aif.TOTAL_LOAD) in self:
                self[aif.TOTAL_LOAD] += self[_containers[container] + aif.TOTAL_LOAD]
'''
