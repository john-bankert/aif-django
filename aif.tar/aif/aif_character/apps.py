from django.apps import AppConfig


class AifCharacterConfig(AppConfig):
    name = 'aif_character'
