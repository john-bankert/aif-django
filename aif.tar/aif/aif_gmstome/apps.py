from django.apps import AppConfig


class AifGmstomeConfig(AppConfig):
    name = 'aif_gmstome'
