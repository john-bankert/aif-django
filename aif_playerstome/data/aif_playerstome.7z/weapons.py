class Weapons:
    def __init__(self):
        self.small_weapons = {
            'Axe Hand/Throwing': {'Cost': '2sp', 'Size': 'S', 'Type': 'C', 'Damage': '1d6+1', 'Range': '(s)',
                                  'Load': '1', 'Dur': '80'},
            'Small Club': {'Cost': '-', 'Size': 'S', 'Type': 'B', 'Damage': '1d6', 'Range': '(s)', 'Load': '1',
                           'Dur': '120'},
            'Dagger': {'Cost': '2sp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6', 'Range': '(s)/2', 'Load': '1',
                       'Dur': '80'},
            'Dart': {'Cost': '5cp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6', 'Range': '(s)', 'Load': '10/1',
                     'Dur': '20'},
            'Fist': {'Cost': '-', 'Size': 'S', 'Type': 'B', 'Damage': '1d6', 'Range': '-', 'Load': '-', 'Dur': '-'},
            'Foot': {'Cost': '-', 'Size': 'S', 'Type': 'B', 'Damage': '1d6+1', 'Range': '-', 'Load': '-', 'Dur': '-'},
            'Knife': {'Cost': '5cp', 'Size': 'S', 'Type': 'S', 'Damage': '1d6', 'Range': '(s)', 'Load': '1',
                      'Dur': '80'},
            'Short Sword': {'Cost': '12sp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6+2', 'Range': '-', 'Load': '2',
                            'Dur': '120'},
            'War Hammer': {'Cost': '3sp', 'Size': 'S', 'Type': 'B', 'Damage': '1d6+1', 'Range': '(s)', 'Load': '2',
                           'Dur': '120'}}
        self.medium_weapons = {
            'Battle Axe': {'Cost': '12sp', 'Size': 'M', 'Type': 'C', 'Damage': '2d6', 'Range': '-', 'Load': '3',
                           'Dur': '160'},
            'Battle Hammer': {'Cost': '10sp', 'Size': 'M', 'Type': 'B', 'Damage': '2d6', 'Range': '-', 'Load': '4',
                              'Dur': '160'},
            'Broad Sword': {'Cost': '20sp', 'Size': 'M', 'Type': 'C', 'Damage': '2d6+1', 'Range': '-', 'Load': '4',
                            'Dur': '180'},
            'Medium Club': {'Cost': '-', 'Size': 'M', 'Type': 'B', 'Damage': '2d6-2', 'Range': '-', 'Load': '2',
                            'Dur': '120'},
            'Flail': {'Cost': '15sp', 'Size': 'M', 'Type': 'B', 'Damage': '2d6-1', 'Range': '-', 'Load': '2',
                      'Dur': '100'},
            'Javelin': {'Cost': '2sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6-2', 'Range': '(s)*2', 'Load': '2',
                        'Dur': '40'},
            'Light Lance': {'Cost': '18sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6+1', 'Range': '(s)/2', 'Load': '4',
                            'Dur': '60'},
            'Long Sword': {'Cost': '30sp', 'Size': 'M', 'Type': 'S', 'Damage': '2d6', 'Range': '-', 'Load': '3',
                           'Dur': '160'},
            'Mace': {'Cost': '14sp', 'Size': 'M', 'Type': 'B', 'Damage': '2d6', 'Range': '(s)', 'Load': '3',
                     'Dur': '140'},
            'Morningstar': {'Cost': '20sp', 'Size': 'M', 'Type': 'B', 'Damage': '2d6+1', 'Range': '-', 'Load': '4',
                            'Dur': '120'},
            'Normal Spear': {'Cost': '3sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6', 'Range': '(s)', 'Load': '2',
                             'Dur': '100'},
            'Pickaxe': {'Cost': '19sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6', 'Range': '-', 'Load': '4',
                        'Dur': '120'},
            'Quarter Staff': {'Cost': '-', 'Size': 'M', 'Type': 'B', 'Damage': '2d6-1', 'Range': '-', 'Load': '2',
                              'Dur': '100'},
            'Rapier': {'Cost': '28sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6', 'Range': '-', 'Load': '1',
                       'Dur': '75'},
            'Sabre': {'Cost': '18sp', 'Size': 'M', 'Type': 'C', 'Damage': '2d6-1', 'Range': '-', 'Load': '3',
                      'Dur': '130'},
            'Scimitar': {'Cost': '25sp', 'Size': 'M', 'Type': 'S', 'Damage': '2d6-1', 'Range': '(s)', 'Load': '2',
                         'Dur': '120'}}
        self.large_weapons = {
            'Bastard Sword': {'Cost': '65sp', 'Size': 'L', 'Type': 'S', 'Damage': '-', 'Range': '-', 'Load': '5',
                              'Dur': '200'},
            'One-handed': {'Cost': '-', 'Size': '-', 'Type': '-', 'Damage': '2d6', 'Range': '-', 'Load': '-',
                           'Dur': '-'},
            'Two-handed(a)': {'Cost': '-', 'Size': '-', 'Type': '-', 'Damage': '3d6', 'Range': '-', 'Load': '-',
                              'Dur': '-'},
            'Great Spear(a)': {'Cost': '8sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6-2', 'Range': '-', 'Load': '4',
                               'Dur': '120'},
            'Medium Lance (a)': {'Cost': '25sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6-1', 'Range': '-', 'Load': '5',
                                 'Dur': '80'},
            'Heavy Lance (a)': {'Cost': '40sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6', 'Range': '-', 'Load': '6',
                                'Dur': '100'},
            'Maul': {'Cost': '35sp', 'Size': 'L', 'Type': 'B', 'Damage': '3d6', 'Range': '-', 'Load': '7',
                     'Dur': '180'},
            'Polearm(a)': {'Cost': '', 'Size': '', 'Type': '', 'Damage': '', 'Range': '', 'Load': '', 'Dur': ''},
            'Bardiche': {'Cost': '27sp', 'Size': 'L', 'Type': 'C', 'Damage': '3d6-1', 'Range': '-', 'Load': '5',
                         'Dur': '100'},
            'Glaive': {'Cost': '26sp', 'Size': 'L', 'Type': 'S', 'Damage': '3d6-2', 'Range': '-', 'Load': '4',
                       'Dur': '80'},
            'Halberd': {'Cost': '40sp', 'Size': 'L', 'Type': 'C', 'Damage': '3d6', 'Range': '-', 'Load': '5',
                        'Dur': '120'},
            'Pike': {'Cost': '12sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6-2', 'Range': '-', 'Load': '3',
                     'Dur': '80'},
            'Ranseur': {'Cost': '16sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6-1', 'Range': '-', 'Load': '4',
                        'Dur': '60'},
            'Spetum': {'Cost': '35sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6', 'Range': '-', 'Load': '4',
                       'Dur': '80'},
            'Voulge': {'Cost': '15sp', 'Size': 'L', 'Type': 'S', 'Damage': '3d6-2', 'Range': '-', 'Load': '4',
                       'Dur': '80'},
            'Ironshod Staff (a)': {'Cost': '20sp', 'Size': 'L', 'Type': 'B', 'Damage': '3d6-1', 'Range': '-',
                                   'Load': '4', 'Dur': '140'},
            'Trident(a)': {'Cost': '20sp', 'Size': 'L', 'Type': 'P', 'Damage': '3d6-1', 'Range': '(s)/2', 'Load': '3',
                           'Dur': '140'},
            'Two-Handed Axe(a)': {'Cost': '60sp', 'Size': 'L', 'Type': 'C', 'Damage': '3d6', 'Range': '-', 'Load': '5',
                                  'Dur': '170'},
            'Two-Handed Sword(a)': {'Cost': '80sp', 'Size': 'L', 'Type': 'C', 'Damage': '3d6', 'Range': '-',
                                    'Load': '6', 'Dur': '240'}}
        self.throwing_weapons = {
            'Axe Hand/Throwing': {'Cost': '2sp', 'Size': 'S', 'Type': 'C', 'Damage': '1d6+1', 'Range': '(s)',
                                  'Load': '1', 'Dur': '80'},
            'Bow(a)': {'Cost': '', 'Size': '', 'Type': '', 'Damage': '', 'Range': '', 'Load': '', 'Dur': ''},
            'Long(c)': {'Cost': '70sp', 'Size': 'M', 'Type': '-', 'Damage': '1d6', 'Range': '-', 'Load': '3',
                        'Dur': '100'},
            'Blunt Arrows': {'Cost': '1cp', 'Size': 'S', 'Type': 'B', 'Damage': '1d6', 'Range': '80', 'Load': '10/1',
                             'Dur': '10'},
            'Flight Arrow': {'Cost': '1cp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6', 'Range': '75', 'Load': '10/1',
                             'Dur': '10'},
            'Frog Crotch Arrow': {'Cost': '1cp', 'Size': 'S', 'Type': 'S', 'Damage': '1d6', 'Range': '105',
                                  'Load': '10/1', 'Dur': '10'},
            'Short': {'Cost': '35sp', 'Size': 'S', 'Type': '-', 'Damage': '-', 'Range': '-', 'Load': '2', 'Dur': '80'},
            'Small Club': {'Cost': '-', 'Size': 'S', 'Type': 'B', 'Damage': '1d6', 'Range': '(s)', 'Load': '1',
                           'Dur': '120'},
            'Crossbow(a)': {'Cost': '', 'Size': '', 'Type': '', 'Damage': '', 'Range': '', 'Load': '', 'Dur': ''},
            'Light': {'Cost': '75sp', 'Size': 'S', 'Type': '-', 'Damage': '-', 'Range': '-', 'Load': '2', 'Dur': '120'},
            'Light Quarrel': {'Cost': '2cp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6+1', 'Range': '120',
                              'Load': '10/1', 'Dur': '30'},
            'Medium': {'Cost': '90sp', 'Size': 'M', 'Type': '-', 'Damage': '-', 'Range': '-', 'Load': '3',
                       'Dur': '140'},
            'Medium Quarrel': {'Cost': '2cp', 'Size': 'S', 'Type': 'P', 'Damage': '2d6', 'Range': '135', 'Load': '10/1',
                               'Dur': '30'},
            'Heavy(b)': {'Cost': '110sp', 'Size': 'M', 'Type': '-', 'Damage': '-', 'Range': '-', 'Load': '4',
                         'Dur': '160'},
            'Heavy Quarrel': {'Cost': '3cp', 'Size': 'S', 'Type': 'P', 'Damage': '3d6', 'Range': '150', 'Load': '10/1',
                              'Dur': '30'},
            'Dagger': {'Cost': '2sp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6', 'Range': '(s)/2', 'Load': '1',
                       'Dur': '80'},
            'Dart': {'Cost': '5cp', 'Size': 'S', 'Type': 'P', 'Damage': '1d6', 'Range': '(s)', 'Load': '10/1',
                     'Dur': '20'},
            'Knife': {'Cost': '5cp', 'Size': 'S', 'Type': 'S', 'Damage': '1d6', 'Range': '(s)', 'Load': '1',
                      'Dur': '80'},
            'Mace': {'Cost': '14sp', 'Size': 'M', 'Type': 'B', 'Damage': '2d6', 'Range': '(s)', 'Load': '3',
                     'Dur': '140'},
            'Normal Spear': {'Cost': '3sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6', 'Range': '(s)', 'Load': '2',
                             'Dur': '100'},
            'Javelin': {'Cost': '2sp', 'Size': 'M', 'Type': 'P', 'Damage': '2d6-2', 'Range': '(s)*2', 'Load': '2',
                        'Dur': '40'},
            'Sling(a)': {'Cost': '2cp', 'Size': 'S', 'Type': '-', 'Damage': '-', 'Range': '-', 'Load': '10/1',
                         'Dur': '20'},
            'Bullet': {'Cost': '2ip', 'Size': 'S', 'Type': 'B', 'Damage': '1d6+1', 'Range': '105', 'Load': '10/1',
                       'Dur': '20'},
            'Stone': {'Cost': '-', 'Size': 'S', 'Type': 'B', 'Damage': '1d6', 'Range': '75', 'Load': '10/1',
                      'Dur': '-'},
            'War Hammer': {'Cost': '3sp', 'Size': 'S', 'Type': 'B', 'Damage': '1d6+1', 'Range': '(s)', 'Load': '2',
                           'Dur': '120'}}
                           
                           
if __name__ == "__main__":

    self = Weapons()
    f = open("weapons.csv", "a")
    for key in self.small_weapons:
        a = self.small_weapons[key]
        line = 'small_weapon, ' + key + ", " + a['Cost'] + ", " + a['Size'] + ", " + a['Type'] + ", " + a['Damage'] + ", " + a['Range'] + ", " + a['Load'] + a['Dur']
        f.write(line + "\n")

    for key in self.medium_weapons:
        a = self.medium_weapons[key]
        line = 'medium_weapon, ' + key + ", " + a['Cost'] + ", " + a['Size'] + ", " + a['Type'] + ", " + a['Damage'] + ", " + a['Range'] + ", " + a['Load'] + a['Dur']
        f.write(line + "\n")

    for key in self.large_weapons:
        a = self.large_weapons[key]
        line = 'large_weapon, ' + key + ", " + a['Cost'] + ", " + a['Size'] + ", " + a['Type'] + ", " + a['Damage'] + ", " + a['Range'] + ", " + a['Load'] + a['Dur']
        f.write(line + "\n")

    for key in self.throwing_weapons:
        a = self.throwing_weapons[key]
        line = 'throwing_weapon, ' + key + ", " + a['Cost'] + ", " + a['Size'] + ", " + a['Type'] + ", " + a['Damage'] + ", " + a['Range'] + ", " + a['Load'] + a['Dur']
        f.write(line + "\n")

    f.close()