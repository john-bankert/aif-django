class Equipment:
    def __init__(self):
        self.miscellaneous = {'Backpack': {'Cost': '2sp', 'Load': '6', 'Dur': '90', 'Capacity': '16'},
                              'Bandoleer': {'Cost': '8sp', 'Load': '2', 'Dur': '80'},
                              'Bedroll': {'Cost': '4sp', 'Load': '3', 'Dur': '50'},
                              'Belt': {'Cost': '1cp', 'Load': '10/1', 'Dur': '60'},
                              'Blanket': {'Cost': '12cp', 'Load': '2', 'Dur': '30'},
                              'Bolt Case': {'Cost': '15cp', 'Load': '1', 'Dur': '120', 'Capacity': '1'},
                              'Leather Book': {'Cost': '10sp', 'Load': '2', 'Dur': '150'},
                              'Boots': {'Cost': '3sp', 'Load': '1', 'Dur': '40'},
                              'Bow string': {'Cost': '5sp', 'Load': '15/1', 'Dur': '30'},
                              'Small Chest': {'Cost': '10sp', 'Load': '15', 'Dur': '120', 'Capacity': '20'},
                              'Medium Chest': {'Cost': '20sp', 'Load': '20', 'Dur': '180', 'Capacity': '30'},
                              'Large Chest': {'Cost': '30sp', 'Load': '25', 'Dur': '240', 'Capacity': '40'},
                              'Cloak': {'Cost': '8cp', 'Load': '1', 'Dur': '30'},
                              'Flask': {'Cost': '2cp', 'Load': '1', 'Dur': '10'},
                              'Flint & Tinder': {'Cost': '5cp', 'Load': '10/1', 'Dur': '40'},
                              'Gloves': {'Cost': '8cp', 'Load': '10/1', 'Dur': '20'},
                              'Hat': {'Cost': '1cp', 'Load': '5/1', 'Dur': '30'},
                              'Holy Symbol': {'Cost': '25sp', 'Load': '10/1', 'Dur': '80'},
                              'Holy Water': {'Cost': '20sp', 'Load': '1', 'Dur': '10'},
                              'Horse Tackle': {'Cost': '100sp', 'Load': '20', 'Dur': '200'},
                              'Bottle of Ink': {'Cost': '9sp', 'Load': '1', 'Dur': '10'},
                              'Iron Spike': {'Cost': '6cp', 'Load': '5/1', 'Dur': '90'},
                              'Lantern': {'Cost': '8sp', 'Load': '3', 'Dur': '40'},
                              'Mallet': {'Cost': '2sp', 'Load': '1', 'Dur': '40'},
                              'Small Mirror': {'Cost': '8sp', 'Load': '1', 'Dur': '20'},
                              'Flask of Oil': {'Cost': '1cp', 'Load': '1', 'Dur': '10'},
                              'Pants': {'Cost': '1cp', 'Load': '1', 'Dur': '40'},
                              'Paper': {'Cost': '2cp', 'Load': '20/1', 'Dur': '6'},
                              'Small Belt Pouch': {'Cost': '5cp', 'Load': '1', 'Dur': '60', 'Capacity': '4'},
                              'Large Belt Pouch': {'Cost': '1sp', 'Load': '2', 'Dur': '60', 'Capacity': '6'},
                              'Pry Bar': {'Cost': '3cp', 'Load': '3', 'Dur': '150'},
                              'Quill': {'Cost': '1sp', 'Load': '10/1', 'Dur': '10'},
                              'Quiver': {'Cost': '8cp', 'Load': '1', 'Dur': '120'},
                              '50ft Rope': {'Cost': '1sp', 'Load': '4', 'Dur': '40'},
                              'Small Sack': {'Cost': '1cp', 'Load': '2', 'Dur': '60', 'Capacity': '8'},
                              'Large Sack': {'Cost': '3cp', 'Load': '3', 'Dur': '60', 'Capacity': '10'},
                              'Scabbard': {'Cost': '5cp', 'Load': '10/1', 'Dur': '80'},
                              'Scroll Case': {'Cost': '12cp', 'Load': '10/1', 'Dur': '60'},
                              'Torch': {'Cost': '2ip', 'Load': '5/1', 'Dur': '40'},
                              'Tunic': {'Cost': '1cp', 'Load': '1', 'Dur': '40'},
                              'Waterskin': {'Cost': '7cp', 'Load': '2/1', 'Dur': '30'}}
        self.tool_list = {'Crafting Kit': {'Cost': '25sp', 'Load': '2', 'Dur': '30'},
                          'Enchanting Kit': {'Cost': '100sp', 'Load': '2', 'Dur': '30'},
                          'Repair Kit': {'Cost': '25sp', 'Load': '3', 'Dur': '30'},
                          "Rogue's Tools": {'Cost': '25sp', 'Load': '1', 'Dur': '120'}}
        self.food_list = {'1 day Rations': {'Cost': '2sp', 'Load': '3/1', 'Dur': '-'},
                          '1 week Rations': {'Cost': '10sp', 'Load': '2', 'Dur': '-'}}

        self.vehicle_list = {'Cart': {'Cost': '150sp', 'Load': '80', 'Capacity': '180', 'Dur': '200'},
                             'Raft': {'Cost': '280sp', 'Load': '70', 'Capacity': '120', 'Dur': '150'},
                             'Rowboat': {'Cost': '400sp', 'Load': '90', 'Capacity': '180', 'Dur': '300'},
                             'Wagon': {'Cost': '450sp', 'Load': '150', 'Capacity': '550', 'Dur': '400'}}
        self.war_horse_barding = {'Light': {'Cost': '100sp', 'Load': '10', 'Dur': '100', 'S': '2', 'P': '1', 'B': '2',
                                            'C': '1'},
                                  'Medium': {'Cost': '200sp', 'Load': '15', 'Dur': '225', 'S': '4', 'P': '3', 'B': '4',
                                             'C': '3'},
                                  'Heavy': {'Cost': '300sp', 'Load': '20', 'Dur': '300', 'S': '5', 'P': '4', 'B': '5',
                                            'C': '4'}}
        self.animal_list = {'Bull': {'Cost': '120sp', 'Capacity': '190'}, 'Cow': {'Cost': '80sp', 'Capacity': '120'},
                            'Hunting Dog': {'Cost': '38sp', 'Capacity': '5'},
                            'War Dog': {'Cost': '100sp', 'Capacity': '15'},
                            'Donkey': {'Cost': '100sp', 'Capacity': '150'},
                            'Draft Horse': {'Cost': '120sp', 'Capacity': '165'},
                            'Riding Horse': {'Cost': '250sp', 'Capacity': '75'},
                            'War Horse': {'Cost': '600sp', 'Capacity': '130'}}
        self.war_dog_barding = {
            'Light': {'Cost': '75sp', 'Load': '5', 'Dur': '50', 'S': '1', 'P': '0', 'B': '1', 'C': '0'},
            'Medium': {'Cost': '150sp', 'Load': '10', 'Dur': '175', 'S': '2', 'P': '1', 'B': '2',
                       'C': '1'},
            'Heavy': {'Cost': '250sp', 'Load': '15', 'Dur': '250', 'S': '3', 'P': '2', 'B': '3',
                      'C': '2'}}
                      
                      
if __name__ == "__main__":

    self = Equipment()
    f = open("equipment.csv", "w")
    for key in self.miscellaneous:
        a = self.miscellaneous[key]
        line = 'miscellaneous, ' + key + ", " + a['Cost'] + ", "
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    for key in self.tool_list:
        a = self.tool_list[key]
        line = 'tools, ' + key + ", " + a['Cost'] + ", "
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    for key in self.food_list:
        a = self.food_list[key]
        line = 'food, ' + key + ", " + a['Cost'] + ", "
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    for key in self.war_horse_barding:
        a = self.war_horse_barding[key]
        line = 'war_horse_barding, ' + key + ", " + a['Cost'] + ", "
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    for key in self.war_dog_barding:
        a = self.war_dog_barding[key]
        line = 'war_dog_barding, ' + key + ", " + a['Cost'] + ", "
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    for key in self.animal_list:
        a = self.animal_list[key]
        line = 'animals, ' + key + ", " + a['Cost']
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    for key in self.vehicle_list:
        a = self.vehicle_list[key]
        line = 'vehicle, ' + key + ", " + a['Cost'] + ", "
        line += (a['Load'] + ", ") if 'Load' in a else ", "
        line += (a['Capacity'] + ", ") if 'Capacity' in a else ", "
        line += (a['S'] + ", ") if 'S' in a else ", "
        line += (a['P'] + ", ") if 'P' in a else ", "
        line += (a['B'] + ", ") if 'B' in a else ", "
        line += (a['C'] + ", ") if 'C' in a else ", "
        line += (a['Dur'] + ", ") if 'Dur' in a else ", "
        f.write(line + "\n")

    f.close()
