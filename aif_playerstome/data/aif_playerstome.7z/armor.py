class Armor:
    def __init__(self):
        self.armor = {'Banded mail': {'Cost': '150sp', 'Type': 'M', 'S': '2', 'P': '3', 'B': '2', 'C': '3', 'Load': '5',
                                      'Carried': '10', 'Dur': '225'},
                      'Chain mail': {'Cost': '100sp', 'Type': 'M', 'S': '3', 'P': '1', 'B': '2', 'C': '3', 'Load': '5',
                                     'Carried': '10', 'Dur': '255'},
                      'Full plate': {'Cost': '1000sp', 'Type': 'H', 'S': '6', 'P': '5', 'B': '6', 'C': '5',
                                     'Load': '10',
                                     'Carried': '20', 'Dur': '400'},
                      'Leather': {'Cost': '20sp', 'Type': 'L', 'S': '1', 'P': '1', 'B': '2', 'C': '2', 'Load': '3',
                                  'Carried': '6', 'Dur': '120'},
                      'Padded': {'Cost': '15sp', 'Type': 'L', 'S': '1', 'P': '1', 'B': '3', 'C': '1', 'Load': '2',
                                 'Carried': '4', 'Dur': '80'},
                      'Plate mail': {'Cost': '650sp', 'Type': 'H', 'S': '5', 'P': '4', 'B': '5', 'C': '4', 'Load': '8',
                                     'Carried': '16', 'Dur': '345'},
                      'Scale mail': {'Cost': '200sp', 'Type': 'M', 'S': '4', 'P': '3', 'B': '2', 'C': '3', 'Load': '7',
                                     'Carried': '14', 'Dur': '210'},
                      'Splint mail': {'Cost': '215sp', 'Type': 'H', 'S': '4', 'P': '2', 'B': '4', 'C': '3', 'Load': '6',
                                      'Carried': '12', 'Dur': '300'},
                      'Studded Leather': {'Cost': '30sp', 'Type': 'L', 'S': '2', 'P': '1', 'B': '2', 'C': '2',
                                          'Load': '4',
                                          'Carried': '8', 'Dur': '165'},
                      'Wool Robe': {'Cost': '10sp', 'Type': '-', 'S': '1', 'P': '1', 'B': '1', 'C': '1', 'Load': '1',
                                    'Carried': '2', 'Dur': '60'}}
        self.shield = {
            'Buckler': {'Cost': '2sp', 'Type': 'L', 'S': '1', 'P': '1', 'B': '2', 'C': '1', 'Load': '1', 'Carried': '2',
                        'Dur': '60'},
            'Small Metal': {'Cost': '6sp', 'Type': 'L', 'S': '2', 'P': '1', 'B': '2', 'C': '1', 'Load': '1',
                            'Carried': '2', 'Dur': '80'},
            'Medium Metal': {'Cost': '14sp', 'Type': 'M', 'S': '2', 'P': '1', 'B': '2', 'C': '1', 'Load': '2',
                             'Carried': '4', 'Dur': '100'},
            'Large Metal': {'Cost': '20sp', 'Type': 'H', 'S': '2', 'P': '1', 'B': '2', 'C': '1', 'Load': '3',
                            'Carried': '6', 'Dur': '120'},
            'Small Wooden': {'Cost': '4sp', 'Type': 'L', 'S': '1', 'P': '1', 'B': '1', 'C': '1', 'Load': '1',
                             'Carried': '2', 'Dur': '40'},
            'Medium Wooden': {'Cost': '8sp', 'Type': 'L', 'S': '1', 'P': '1', 'B': '1', 'C': '1', 'Load': '2',
                              'Carried': '4', 'Dur': '60'},
            'Large Wooden': {'Cost': '12sp', 'Type': 'M', 'S': '1', 'P': '1', 'B': '1', 'C': '1', 'Load': '3',
                             'Carried': '6', 'Dur': '80'}}
        self.helmet = {'Wizard Hat': {'Cost': '1sp', 'Type': '-', 'S': '0', 'P': '0', 'B': '1', 'C': '1', 'Load': '1',
                                      'Carried': '1', 'Dur': '20'},
                       'Cap': {'Cost': '4sp', 'Type': 'L', 'S': '2', 'P': '1', 'B': '2', 'C': '1', 'Load': '1',
                               'Carried': '2', 'Dur': '60'},
                       'Leather': {'Cost': '2sp', 'Type': 'L', 'S': '1', 'P': '1', 'B': '1', 'C': '1', 'Load': '1',
                                   'Carried': '2', 'Dur': '40'},
                       'Open-faced': {'Cost': '22sp', 'Type': 'M', 'S': '2', 'P': '2', 'B': '2', 'C': '2', 'Load': '2',
                                      'Carried': '4', 'Dur': '100'},
                       'Mail coif': {'Cost': '18sp', 'Type': 'M', 'S': '2', 'P': '1', 'B': '1', 'C': '1', 'Load': '2',
                                     'Carried': '4', 'Dur': '80'},
                       'Great helm': {'Cost': '60sp', 'Type': 'H', 'S': '3', 'P': '3', 'B': '3', 'C': '3', 'Load': '3',
                                      'Carried': '6', 'Dur': '120'}}
                                      


if __name__ == "__main__":

    self = Armor()
    f = open("armor.csv", "a")
    for key in self.armor:
        a = self.armor[key]
        line = 'armor, ' + key + ", " + a['Cost'] + ", " + a['Type'] + ", " + a['S'] + ", " + a['P'] + ", " + a['B'] + ", " + a['C'] + ", " + a['Load'] + ", " + a['Carried'] + ", " + a['Dur']
        f.write(line + "\n")

    for key in self.shield:
        a = self.shield[key]
        line = 'shield, ' + key + ", " + a['Cost'] + ", " + a['Type'] + ", " + a['S'] + ", " + a['P'] + ", " + a['B'] + ", " + a['C'] + ", " + a['Load'] + ", " + a['Carried'] + ", " + a['Dur']
        f.write(line + "\n")

    for key in self.helmet:
        a = self.helmet[key]
        line = 'helmet, ' + key + ", " + a['Cost'] + ", " + a['Type'] + ", " + a['S'] + ", " + a['P'] + ", " + a['B'] + ", " + a['C'] + ", " + a['Load'] + ", " + a['Carried'] + ", " + a['Dur']
        f.write(line + "\n")

    f.close()
